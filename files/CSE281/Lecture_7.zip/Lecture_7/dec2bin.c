#include<stdio.h>

int main() {
	int i, d, n, bin;
	printf("Enter a decimal number: ");
	scanf("%d", &n);
	bin = 0;
	i = 1;
	while(n>=1) {
		d=n%2;
		bin=bin+i*d;
		i=i*10;
		n=n/2;
	}
	printf("Binary: %d\n", bin);
	return 0;
}
