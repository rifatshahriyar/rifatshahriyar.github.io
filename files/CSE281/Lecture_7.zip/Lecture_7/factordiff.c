#include<stdio.h>

int main()
{
    int i, n, min, max;
    printf("Enter n: ");
    scanf("%d", &n);
    min = n;
    max = 1;
    for ( i = 2; i < n; i++)
    {
        if ( n % i == 0)
        {
            if ( i < min )
            {
                min = i;
            }
            if ( i > max)
            {
                max = i;
            }
        }
    }
    printf("Difference of maximum and minimum factor of %d is %d", n, max-min);
    return 0;
}
