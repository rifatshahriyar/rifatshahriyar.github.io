#include<stdio.h>
// 1 + (1+x) + (1+x+x2) + (1+x+x2+x3) +...
int main() {
	int i, x, n;
	int term, sum, finalsum;
	printf("Enter x and n: ");
	scanf("%d%d", &x, &n);
	sum = 1;
	term = 1;
	finalsum = 1;
	for (i = 1; i<=n; i++)
	{
		term = term*x; 
		sum = sum + term; 
		finalsum = finalsum + sum; 
	}
	printf("%d\n", finalsum);
	return 0;
}
