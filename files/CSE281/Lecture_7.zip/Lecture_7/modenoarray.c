#include<stdio.h>

int main() {
    int i, n, x;
    int icnt, imode, imodecnt, prev;
    printf("How many numbers: ");
    scanf("%d", &n);
    scanf("%d", &x);
    icnt = imodecnt = 1;
    imode = prev = x;
    for (i = 1; i < n; i++) {
        scanf("%d", &x);
        if (prev == x) {
            icnt++;
        }
        else {
            prev = x;
            icnt = 1;
        }
        if (icnt > imodecnt) {
            imodecnt = icnt;
            imode = prev;
        }
    }
    printf("Mod: %d, %d times\n", imode, imodecnt);
    return 0;
}
