#include<stdio.h>

int main() {
    double x, sum, term;
    int i;
    printf("Enter x: ");
    scanf("%lf", &x);
    sum = 1;
    term = 1;
    for ( i = 1; i <= 100; i++) {
        term = term * (x/i);
        sum = sum + term;
    }
    printf("Result: %lf\n", sum);
    return 0;
}