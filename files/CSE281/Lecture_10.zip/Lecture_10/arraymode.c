#include<stdio.h>

int main() {
    int i, j, index, N, max, count;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    max = count = 0;
    for (i = 0; i < N; i++) {
        count = 1;
        for (j=i+1; j < N; j++) {
            if (a[i] == a[j]) {
                count++;
            }
        }
        if (count > max) {
            max = count; 
            index = i;
        }
        //printf("%d - %d %d\n", a[i], count, max);
    }
    printf("Mode is %d - %d times\n", a[index], max);
    return 0;
}