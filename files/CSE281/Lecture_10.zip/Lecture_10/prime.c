#include<stdio.h>

int main() {
    int i, j, n, isPrime;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("List of Prime Numbers: ");
    for ( i = 1; i <=n; i++) {
            isPrime = 1;
            for ( j = 2; j * j <= i; j++) {
                if ( i % j == 0) {
                    isPrime = 0;
                    break;
                }
            }
            if ( isPrime == 1) {
                printf("%d ", i);
            }
    }
    printf("\n");
    return 0;
}