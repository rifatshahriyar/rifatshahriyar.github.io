#include<stdio.h>

int main() {
    int i, j, pos, N, c;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    for ( i=0; i < N-1; i++ ) {
        pos = i;
        for ( j = i+1; j < N; j++ ) {
            if (a[j] < a[pos]) { // find the index of the minimum element 
                pos  = j;
            }
        }
        if ( i != pos) {
            c = a[i];
            a[i] = a[pos];
            a[pos] = c;
        }
    }
    printf("Sorted Array: ");
    for (i = 0; i < N; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
    return 0;
}