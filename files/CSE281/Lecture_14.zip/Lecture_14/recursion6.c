#include<stdio.h>

void toh(int n, char src, char dst, char tmp)
{
    if (n == 1)
    {
        printf("Move disk 1 from peg %c to peg %c\n", src, dst);
        return;
    }
    toh(n - 1, src, tmp, dst);
    printf("Move disk %d from peg %c to peg %c\n", n, src, dst);
    toh(n - 1, tmp, dst, src);
}

int main()
{
    int N;
    printf("Enter number of disks: ");
    scanf("%d", &N);
    toh(N, 'S', 'D', 'T');
    return 0;
}
