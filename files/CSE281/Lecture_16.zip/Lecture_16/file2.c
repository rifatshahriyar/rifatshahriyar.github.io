#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE * fp;
    char str[] = "This is a file system test.\n";
    int i = 0;
    fp = fopen("f2.txt", "w"); // fp = fopen("f2.txt", "a") will append
    if (fp == NULL)
    {
        printf("File doesn't exists!\n");
        exit(1);
    }
    printf("File successfully opened\n");

    while(str[i])
    {
        int ret = fputc(str[i], fp); // to write a character in a file
        if (ret == EOF)
        {
            printf("Error writing file!\n");
            exit(1);
        }
        i++;
    }


    printf("File successfully written\n");
    fclose(fp);
    return 0;
}
