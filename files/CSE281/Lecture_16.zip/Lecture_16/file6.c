#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    FILE * fp;
    char str[80];
    int i;
    float f;

    fp = fopen("f6.txt", "w");
    if (fp == NULL)
    {
        printf("File doesn't exists!\n");
        exit(1);
    }

    fprintf(fp, "%f %d ", 100.5, 20);
    fputs("hello world\n", fp);
    fprintf(fp, "%f %d ", 345.5, 10);
    fputs("world hello\n", fp);
    fclose(fp);

    fp = fopen("f6.txt", "r");
    if (fp == NULL)
    {
        printf("File doesn't exists!\n");
        exit(1);
    }

    while (!feof(fp))
    {
        fscanf(fp, "%f %d ", &f, &i);
        fgets(str, 80, fp);
        if (!feof(fp))
            printf("%f %s %d\n", f, str, i);
    }

    fclose(fp);
    return 0;
}
