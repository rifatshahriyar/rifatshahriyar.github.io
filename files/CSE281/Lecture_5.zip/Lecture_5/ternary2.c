#include<stdio.h>

int main( )
{
    char ch;
    char x;
    printf("Enter a character: ");
    scanf("%c", &ch);
    x = (ch>='A' && ch<='Z') ? ch+('a'-'A') : ( (ch>='a' && ch<='z') ? ch-('a'-'A') : ch );
    printf("%c\n", x);
    return 0;
}

