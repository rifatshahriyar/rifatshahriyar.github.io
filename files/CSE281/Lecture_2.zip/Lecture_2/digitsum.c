#include<stdio.h>

int main() {
	int n; // 4 digit number
	int d1, d2, d3, d4; // 4 digits
	int m, sum;
	printf("Enter the 4 digit number: ");
	scanf("%d", &n);
	m  = n; // remember n
	
	d1 = n % 10; // first digit
	n = n / 10;
	
	d2 = n % 10; // second digit
	n = n / 10;
	
	d3 = n % 10; // third digit
	n = n / 10;
	
	d4 = n % 10; // fourth digit
	
	sum = d1 + d2 + d3 + d4;
	
	printf("Digits of %d are %d, %d, %d and %d, Sum %d\n", m, d1, d2, d3, d4, sum);
	return 0;
}