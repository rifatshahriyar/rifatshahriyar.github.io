#include<stdio.h>

int main() {
	char c;
	int i;
	float f;
	double d;
	c = 'a';
	i = 100;
	f = 12.34;
	d = 1234567.89123;
	printf("c = %c, %lu\n", c, sizeof(char));
	printf("i = %d, %lu\n", i, sizeof(int));
	printf("f = %f, %lu\n", f, sizeof(float));
	printf("d = %lf, %lu\n", d, sizeof(double));
	return 0;
}
