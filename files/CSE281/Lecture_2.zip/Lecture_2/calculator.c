#include<stdio.h>

int main() {
	int a, b;
	int sum, sub, mult;
	float div; // division can contain fraction, so float
	printf("Enter two integers: ");
	scanf("%d %d", &a, &b);
	sum = a + b;
	sub = a - b;
	mult = a * b;
	// div = a / b;  // this will not work 
	div = (float) a / b; 
	// div = a / (float) b; // this will also work
	// div = (float) a/ (float) b;  // this will also work
	printf("Sum: %d\n", sum);
	printf("Sub: %d\n", sub);
	printf("Mult: %d\n", mult);
	printf("Div: %f\n", div);
	return 0;
}