#include<stdio.h>

int main() {
    int a = 10;
    int b = 20;
    printf("%d\n", a > 0 && b > 0);
    b = 0;
    printf("%d\n", a > 0 || b > 0);
    printf("%d\n", !a);
    return 0;
}
