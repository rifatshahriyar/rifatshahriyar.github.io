#include<stdio.h>

int main() {
	int a, b;
	printf("Enter two integers (a and b): ");
	scanf("%d%d", &a, &b); // a = your input, b = your input
	printf("a = %d\n", a);
	printf("b = %d\n", b);
	return 0;
}