#include<stdio.h>

int main() {
    int a = 10;
    int b;
    a++;
    printf("a = %d\n", a);
    ++a;
    printf("a = %d\n", a);
    b = a++;
    printf("a = %d, b = %d\n", a, b);
    b = ++a;
    printf("a = %d, b = %d\n", a, b);
    b = a++ + a++;
	printf("a = %d, b = %d\n", a, b);
	b = ++a + ++a;
	printf("a = %d, b = %d\n", a, b);
	b = (++a) + (++a);
	printf("a = %d, b = %d\n", a, b);
    a+=b; // a = a + b
    a-=b; // a = a - b
    a*=b; // a = a * b
    a/=b; // a = a / b;
    a%=b; // a = a % b
    return 0;
}
