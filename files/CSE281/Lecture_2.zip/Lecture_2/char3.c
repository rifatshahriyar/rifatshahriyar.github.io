#include<stdio.h>

int main() {
    char c;
    int n;
    char t;
    printf("Enter a character: "); 
    scanf("%c", &c); 
    printf("Enter a number: "); 
    scanf("%d", &n);
    t = (c - 'a' - n + 26) % 26 + 'a'; 
    printf("%c\n",  t );
    return 0;
}
