#include<stdio.h>

int main() {
    int small, large, goal;
    // small - 1 inches
    // large - 5 inches
    // goal - inches
    printf("Enter number of small and large sticks: ");
	scanf("%d%d", &small, &large);
	printf("Enter goal in inches: ");
	scanf("%d", &goal);
    if (small + large * 5 < goal) printf("Not Possible"); // not enough sticks
    else if (goal % 5 < small) printf("Not Possible"); // not enough small sticks
    else printf("Possible");
    return 0;
}
