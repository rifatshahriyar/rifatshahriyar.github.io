#include<stdio.h>

int main()
{
    int num;
    char grade;
    printf("Enter your number: ");
    scanf("%d", &num);

    if (num >= 90 )
    {
        grade = 'A';
    }
    else if ( num >= 80)
    {
        grade = 'B';
    }
    else if (num >= 70)
    {
        grade = 'C';
    }
    else if (num >= 60)
    {
        grade = 'D';
    }
    else
    {
        grade = 'F';
    }

    printf("Your grade: %c\n", grade);
    return 0;
}
