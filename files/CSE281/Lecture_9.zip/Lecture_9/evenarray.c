#include<stdio.h>

int evencount(int a[], int n) {
    int i;
    int cnt = 0;
    for ( i = 0; i < n; i++) {
        if ( a[i] % 2 == 0) {
            cnt++;
        }
    }
    return cnt;
}
int main() {
    int i, n, count;
    printf("Enter number of elements: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the numbers: ");
    for (i = 0; i < n; i++) {
    	scanf("%d", &a[i]);
    }
    count = evencount(a, n);
    printf("Total number of even elements is %d\n", count);
    return 0;
}
