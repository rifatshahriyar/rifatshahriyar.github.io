#include<stdio.h>

void sum() {
    int a, b, c;
    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);
    c = a + b;
    printf("Sum: %d\n", c);
}

int main() {
    sum();
    return 0;
}
