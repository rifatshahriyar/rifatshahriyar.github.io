#include<stdio.h>

int g;

void f() {
    printf("In f, g = %d\n", g);
    g = 20;
    printf("In f, g = %d\n", g);
}

int main() {
    printf("In main, g = %d\n", g);
    g = 10;
    printf("In main, g = %d\n", g);
    f();
    printf("In main, g = %d\n", g);
    return 0;
}
