#include<stdio.h>

int factorsum(int n) {
    int i;
    int sum = 0;
    for ( i = 1; i <= n/2; i++) {
        if ( n % i == 0) {
            sum = sum + i;
        }
    }
    return sum;
}
int main() {
    int n, fsum;
    printf("Enter n: ");
    scanf("%d", &n);
    fsum = factorsum(n);
    printf("Sum of factor of %d is %d\n", n, fsum);
    return 0;
}
