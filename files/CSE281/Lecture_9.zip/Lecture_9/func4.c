#include<stdio.h>

int sum(int a, int b) {
    return a + b;
}

int main() {        
    int x, y, z;
    printf("Enter two numbers: ");
    scanf("%d%d", &x, &y);
    z = sum(x, y);
    printf("Sum: %d\n", z);
    return 0;
}
