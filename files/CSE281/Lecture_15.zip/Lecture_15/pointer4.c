#include<stdio.h>

int main() {
    int a = 10;
    int *p = &a;

    printf("a = %d\n", a);
    printf("p = %p\n", p);
    printf("*p= %d\n", *p);

    p = p + 2; // valid
    printf("After add p = %p\n", p);
    p = p  - 2; // valid
    printf("After sub p = %p\n", p);
    // p = p * 1; // multiplication is not valid
    // p = p / 1; // division is not valid
    int *q = &a;
    int diff  = p - q;
    printf("Pointer Difference : %d\n", diff);

    return 0;
}
