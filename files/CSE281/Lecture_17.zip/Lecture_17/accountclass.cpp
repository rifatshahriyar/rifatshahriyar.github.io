#include<iostream>
using namespace std;

class account
{
// everything is by default private for class
private:
  int accountNo;
  double balance;
public:
  account() {
    // the constructor name is same as the class name with no return type
    cout << "This is a constructor, which is automatically called" << endl;
    balance = 1100;
  }
  account(int accNo, int initialBalance) {
    // the constructor name is same as the class name with no return type
    cout << "This is a parameterized constructor, which is automatically called" << endl;
    accountNo = accNo;
    balance = initialBalance;
  }
  void setAccountNo(int accNo) {
    accountNo = accNo;
  }
  void debit(double val) {
    balance-=val;
  }
  void credit(double val) {
    balance+=val;
  }
  void print() {
    cout << accountNo << ", " << balance << endl;
  }
};

int main() {
  account a;
  a.setAccountNo(1001);
  // a.balance = 100; // ERROR
  a.debit(100);
  a.credit(300);
  a.print();
  account b(1002, 1500);
  // b.accountNo = 1003; // ERROR
  b.debit(500);
  b.credit(200);
  b.print();
  return 0;
}
