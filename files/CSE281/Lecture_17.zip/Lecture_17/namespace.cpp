#include<iostream>
using namespace std;

namespace CSE
{
  void printDepartment() {
    cout << "CSE" << endl;
  }

  void printCSE() {
    cout << "Computer Science and Engineering" << endl;
  }
}

namespace BME
{
  void printDepartment() {
    cout << "BME" << endl;
  }

  void printBME() {
    cout << "Biomedical Engineering" << endl;
  }
}

void printDepartment() {
  cout << "EEE" << endl;
}

using namespace CSE;
using namespace BME;

int main() {
  CSE::printDepartment();
  BME::printDepartment();
  ::printDepartment(); // printDepartment();
  printCSE(); // CSE::printCSE();
  printBME(); // BME::printBME();
  return 0;
}
