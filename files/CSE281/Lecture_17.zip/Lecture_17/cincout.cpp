#include<iostream>
using namespace std;

int main() {
  char c;
  int i;
  float f;
  string s;

  cout << "Enter a character: "; // std::count
  cin >> c; // std::cin
  cout << "Enter an integer: ";
  cin >> i;
  cout << "Enter a float: ";
  cin >> f;
  cout << "Enter a string: ";
  cin >> s;
  // cin >> c >> i >> f >> s;
  cout << c << ", " << i << ", " << f << ", " << s << endl;
  return 0;
}
