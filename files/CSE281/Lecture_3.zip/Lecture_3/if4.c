#include<stdio.h>

int main()
{
    if (0)
    {
        // this block will never execute
        printf("Always false\n");
    }
    if (1)
    {
        // this block will always execute
        printf("Always true\n");
    }
    if (5)
    {
        // this block will always execute
        printf("Always true\n");
    }
    if (-5)
    {
        // this block will always execute
        printf("Always true\n");
    }
    return 0;
}
