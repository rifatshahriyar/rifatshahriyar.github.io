#include<stdio.h>

int main()
{
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    if ( a > b )
    {
        // everything inside this { } is part of the if
        printf("a is greater\n");
    }
    return 0;
}
