#include<stdio.h>

int main()
{
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    if ( a = b )   // this is not equality test, this is assignment, so if (a =b) will be if(a)
    {
        printf("a equals b\n");
    }
    // try this program with
    // a = 10 b = 0
    // a = 10 b = 10
    // a = 10 b = 5
    // a = 10 b = -10
    // In C, 0 means false, anything else is true
    return 0;
}
