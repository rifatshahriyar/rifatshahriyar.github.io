#include<stdio.h>

int main() {
    int i, n, sum, mult;
    sum = 0;
    mult = 1;
    printf("Enter n: ");
    scanf("%d", &n);
    for ( i = 1; i<=n; i++) {
        sum = sum + i;
        mult = mult * i;
    }
    printf("Sum: %d, Mult: %d\n", sum, mult);
    return 0;
}