#include<stdio.h>

void f(int a[], int N) {
    int i;
    for (i = 0; i < N; i++) {
        printf("%d ", a[i]);
    }   
    a[0] = 0;
    a[N-1] = 0; // these changes will be seen in main 
    printf("\n");
}

int main() {
    int i, N;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    f(a, N);
    for (i = 0; i < N; i++) {
        printf("%d ", a[i]);
    }   
    printf("\n");
    return 0;
}
