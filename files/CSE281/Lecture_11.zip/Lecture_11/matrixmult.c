#include<stdio.h>

int main() {
    int i, j, k, r1, c1, r2, c2, sum;

    printf("Enter number of rows for first matrix: ");
    scanf("%d", &r1);
    printf("Enter number of columns for the first matrix: ");
    scanf("%d", &c1);
    
     printf("Enter number of rows for second matrix: ");
    scanf("%d", &r2);
    printf("Enter number of columns for the second matrix: ");
    scanf("%d", &c2);
    
    if ( c1 != r2) {
        printf("Invalid Dimension\n");
        return 0;
    }
    
    int x[r1][c1], y[r2][c2], z[r1][c2];
    
    printf("Enter first matrix (separate by space): ");
    for ( i =0 ; i< r1; i++ ) {
        for ( j = 0; j < c1; j++ ) {
            scanf("%d", &x[i][j]);
        }
    }
    
    printf("Enter second matrix (separate by space): ");
    for ( i =0 ; i< r2; i++ ) {
        for ( j = 0; j < c2; j++ ) {
            scanf("%d", &y[i][j]);
        }
    }   
    
    for ( i =0 ; i< r1; i++ ) {
        for ( j = 0; j < c2; j++ ) {
            sum = 0;
            for ( k = 0; k < r2; k++ ) {
                sum += x[i][k] * y[k][j];
            }
            z[i][j] = sum; 
        }
    }
    
    printf("The resulting summation matrix: \n");
    for ( i =0 ; i< r1; i++ ) {
        for ( j = 0; j < c2; j++ ) {
            printf("%d ", z[i][j]);
        }
        printf("\n");
    }
    return 0;
}