#include<stdio.h>

void f(int a, int N) {
    printf("%d\n", a);
    a = 100;  // these changes will not be seen in main
    printf("%d\n", a); 
}

int main() {
    int i, N;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    f(a[0], N);
    for (i = 0; i < N; i++) {
        printf("%d ", a[i]);
    }  
    printf("\n"); 
    return 0;
}
