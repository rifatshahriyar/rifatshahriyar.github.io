#include<stdio.h>

int main() {
    // one dimensional array to hold temperature of each day of a year
    float tmpday[366] = { };
     // two dimensional array to hold temperature of each day of a year month wise
    float tmpmonth[12][31] = { };
    return 0;
}