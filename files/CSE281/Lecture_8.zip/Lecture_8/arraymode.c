#include<stdio.h>

int main() {
    int i, N, x, maxCount, mode;
    printf("How many numbers: ");
    scanf("%d", &N);
    printf("Enter numbers between 0 to 9\n");
    int a[N]; 
    int b[10] = {};
    for (i = 0; i < N; i++) {
	scanf("%d", &a[i]);
    }
    for (i = 0; i < N; i++) {
	b[a[i]]++;
    }
    maxCount = b[0];
    mode = 0;
    for (i = 0; i < N; i++) {
	if (maxCount < b[i]) {
		maxCount = b[i];
		mode = i;
	}
    }
    printf("Mod: %d, %d times\n", mode, maxCount);
    return 0;
}
