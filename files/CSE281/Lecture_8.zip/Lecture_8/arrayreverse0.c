#include<stdio.h>

int main() {
    int i, N, tmp;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    int b[N];
    printf("Enter the numbers: ");
    for ( i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    /*for ( i = 0, j = N-1; i < N; i++, j--) {
        b[j] = a[i];
     }*/
    for ( i = 0; i < N; i++) {
        b[N-i-1] = a[i];
     }
    printf("Reverse: ");
    for ( i = 0; i < N; i++) {
        printf("%d ", b[i]);
    }
    printf("\n");
    return 0;
}