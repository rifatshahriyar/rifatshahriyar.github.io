#include<stdio.h>

int main()
{
    // string declaration
    char s[] = {'h', 'e', 'l', 'l', 'o', '\0', 'w', 'o', 'r', 'l', 'd'};
    char t[] = "hello world";
    // print character by character
    int i = 0;
    while(t[i] != '\0')
    {
        printf("%c", t[i]);
        i++;
    }
    printf("\n");
    // print using %s in printf
    printf("%s\n", s);
    printf("%s\n", t);
    return 0;
}
