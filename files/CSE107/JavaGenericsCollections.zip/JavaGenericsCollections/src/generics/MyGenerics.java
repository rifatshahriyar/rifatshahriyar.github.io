package generics;

public class MyGenerics<T> {
    private T a;

    public void setObj(T a) {
        this.a = a;
    }

    public T getObj() {
        return this.a;
    }

    public static void main(String[] args) {
        MyGenerics<Integer>myGenerics = new MyGenerics<>();
        myGenerics.setObj(10);
        System.out.println(myGenerics.getObj());
        MyGenerics<String> myGenerics1 = new MyGenerics<>();
        myGenerics1.setObj("Hello");
        String str = myGenerics1.getObj();
        System.out.println(str);
        MyGenerics noGenerics = new MyGenerics(); // still possible
        noGenerics.setObj(20);
        noGenerics.setObj("World");
        System.out.println(noGenerics.getObj());
    }
}


