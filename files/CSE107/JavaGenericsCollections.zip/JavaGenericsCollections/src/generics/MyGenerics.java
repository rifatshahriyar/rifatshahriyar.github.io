package generics;

public class MyGenerics<T> {
    private T a;

    public void setObj(T a) {
        this.a = a;
    }

    public T getObj() {
        return this.a;
    }

    public static void main(String[] args) {
        MyGenerics<Integer> myGenerics = new MyGenerics<>();
        myGenerics.setObj(10);
        System.out.println(myGenerics.getObj());
        MyGenerics<String> myGenerics1 = new MyGenerics<>();
        myGenerics1.setObj("Hello");
        System.out.println(myGenerics1.getObj());
        // MyGenerics<int> myGenerics2 = new MyGenerics<>();
    }
}


