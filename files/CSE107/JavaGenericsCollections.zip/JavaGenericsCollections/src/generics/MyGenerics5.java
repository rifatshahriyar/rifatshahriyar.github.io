package generics;

interface Stack<T extends Number> {
	void push(T e);
	T pop();
	T top();
	boolean isEmpty();
}

class MyStack<T extends Number> implements Stack<T> {
	T s[];
	int top;
	
	MyStack(int capacity) {
		s = (T[])new Number[capacity];
        top = -1;
	}
	
	public void push(T e) {
	    s[++top] = e;
	}
	
	public T pop() {
		return s[top--];
	}
	
	public boolean isEmpty() {
		return top == -1;
	}

	public T top() {
		return s[top];
	}
}

public class MyGenerics5 {
	public static void main(String args[]) {
		//MyStack<String> mss = new MyStack<>(20);
		MyStack<Integer> ms = new MyStack<>(20);
		ms.push(10);
		ms.push(20);
		ms.push(30);
		ms.push(40);
		ms.push(50);
		while (!ms.isEmpty()) {
			System.out.println(ms.pop());
		}

	}
}


