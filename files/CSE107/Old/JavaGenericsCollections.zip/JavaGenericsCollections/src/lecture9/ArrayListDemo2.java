package lecture9;

import java.util.ArrayList;
import java.util.List;

class MyClass {
    String name;
    MyClass(String name) {
        this.name = name;
    }
}

public class ArrayListDemo2 {

    public static void main(String args[]) {
        // create an array list
        List<MyClass> al = new ArrayList<>();
        System.out.println("Initial size of al: " + al.size());

        // add elements to the array list
        al.add(new MyClass("C"));
        al.add(new MyClass("A"));
        al.add(new MyClass("E"));
        al.add(new MyClass("B"));
        al.add(new MyClass("D"));
        al.add(new MyClass("F"));
        al.add(1, new MyClass("A2"));

        System.out.println("Size of al after additions: " + al.size());

        // iterate
        for (int i = 0; i < al.size(); i++) {
            MyClass mc = al.get(i);
            System.out.print(mc.name + "  ");
        }
        System.out.println("");
    }
}