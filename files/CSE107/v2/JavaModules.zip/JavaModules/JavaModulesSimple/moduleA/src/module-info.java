module A {
    exports p1;
}