module B {
    requires A;
}