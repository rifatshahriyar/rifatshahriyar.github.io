module C {
    requires B;
}