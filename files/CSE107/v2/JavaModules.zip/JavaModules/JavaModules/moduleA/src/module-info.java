module A {
    exports p1 to B, C;
}