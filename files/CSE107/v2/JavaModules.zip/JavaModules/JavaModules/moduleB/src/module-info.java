module B {
    requires transitive A;
    exports p2;
}