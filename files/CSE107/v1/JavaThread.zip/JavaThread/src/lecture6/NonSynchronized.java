package lecture6;

class SharedConsole {
    void print(String msg) {
        System.out.print("[" + msg);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
        }
        System.out.println("]");
    }
}

class UserConsoleNoSync implements Runnable {
    String msg;
    SharedConsole console;
    Thread t;

    public UserConsoleNoSync(SharedConsole c, String s) {
        console = c;
        msg = s;
        t = new Thread(this);
        t.start();
    }

    public void run() {
        console.print(msg);
    }
}

public class NonSynchronized {
    public static void main(String[] args) {
        SharedConsole target = new SharedConsole();
        UserConsoleNoSync ob1 = new UserConsoleNoSync(target, "Hello");
        UserConsoleNoSync ob2 = new UserConsoleNoSync(target, "Synchronized");
        UserConsoleNoSync ob3 = new UserConsoleNoSync(target, "World");
    }
}
