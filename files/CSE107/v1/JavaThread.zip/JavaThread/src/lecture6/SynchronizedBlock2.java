package lecture6;

class SharedConsole4 {
     void print(String msg) {
        System.out.print("[" + msg);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
        }
        System.out.println("]");
    }
}

class UserConsoleSync4 implements Runnable {
    String msg;
    SharedConsole4 console;
    Thread t;

    public UserConsoleSync4(SharedConsole4 c, String s) {
        console = c;
        msg = s;
        t = new Thread(this);
        t.start();
    }

    public void run() {
        synchronized (console) {
            console.print(msg);
        }
    }
}

public class SynchronizedBlock2 {
    public static void main(String[] args) {
        SharedConsole4 target = new SharedConsole4();
        UserConsoleSync4 ob1 = new UserConsoleSync4(target, "Hello");
        UserConsoleSync4 ob2 = new UserConsoleSync4(target, "Synchronized");
        UserConsoleSync4 ob3 = new UserConsoleSync4(target, "World");
    }
}
