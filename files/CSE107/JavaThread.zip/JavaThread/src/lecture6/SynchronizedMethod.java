package lecture6;

class SharedConsole1 {
    synchronized void print(String msg) {
        System.out.print("[" + msg);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
        }
        System.out.println("]");
    }
}

class UserConsoleSync implements Runnable {
    String msg;
    SharedConsole1 console;
    Thread t;

    public UserConsoleSync(SharedConsole1 c, String s) {
        console = c;
        msg = s;
        t = new Thread(this);
        t.start();
    }

    public void run() {
        console.print(msg);
    }
}

public class SynchronizedMethod {
    public static void main(String[] args) {
        SharedConsole1 target = new SharedConsole1();
        UserConsoleSync ob1 = new UserConsoleSync(target, "Hello");
        UserConsoleSync ob2 = new UserConsoleSync(target, "Synchronized");
        UserConsoleSync ob3 = new UserConsoleSync(target, "World");
    }
}
