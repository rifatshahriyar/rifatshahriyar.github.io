package lecture6;

class SharedConsole2 {
     void print(String msg) {
        System.out.print("[" + msg);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
        }
        System.out.println("]");
    }
}

class UserConsoleSync2 implements Runnable {
    String msg;
    SharedConsole2 console;
    Thread t;

    public UserConsoleSync2(SharedConsole2 c, String s) {
        console = c;
        msg = s;
        t = new Thread(this);
        t.start();
    }

    public void run() {
        synchronized (console) {
            console.print(msg);
        }
    }
}

public class SynchronizedBlock {
    public static void main(String[] args) {
        SharedConsole2 target = new SharedConsole2();
        UserConsoleSync2 ob1 = new UserConsoleSync2(target, "Hello");
        UserConsoleSync2 ob2 = new UserConsoleSync2(target, "Synchronized");
        UserConsoleSync2 ob3 = new UserConsoleSync2(target, "World");
    }
}
