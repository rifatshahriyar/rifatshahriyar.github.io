package lecture6;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

class SharedConsole3 {
    Lock lock = new ReentrantLock();
     void print(String msg) {
         lock.lock();
         System.out.print("[" + msg);
         try {
            Thread.sleep(1000);
         } catch (InterruptedException e) {
            System.out.println("Interrupted");
         }
         System.out.println("]");
         lock.unlock();
     }
}

class UserConsoleSync3 implements Runnable {
    String msg;
    SharedConsole3 console;
    Thread t;

    public UserConsoleSync3(SharedConsole3 c, String s) {
        console = c;
        msg = s;
        t = new Thread(this);
        t.start();
    }

    public void run() {
        console.print(msg);
    }
}

public class SynchronizationLock {
    public static void main(String[] args) {
        SharedConsole3 target = new SharedConsole3();
        UserConsoleSync3 ob1 = new UserConsoleSync3(target, "Hello");
        UserConsoleSync3 ob2 = new UserConsoleSync3(target, "Synchronized");
        UserConsoleSync3 ob3 = new UserConsoleSync3(target, "World");
    }
}
