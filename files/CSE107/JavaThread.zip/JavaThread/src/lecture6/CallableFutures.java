package lecture6;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class MyCallable implements Callable {

    @Override
    public Integer call() throws Exception {
        int sum = 0;
        for (int i = 0; i <= 100; i++) {
            sum += i;
            Thread.sleep(1000);
        }
        return sum;
    }
}

public class CallableFutures {

    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(10);

        List<Future> list = new ArrayList<Future>();
        for (int i = 0; i < 20; i++) {
            Future submit = executor.submit(new MyCallable());
            list.add(submit);
        }

        int sum = 0;
        // Now retrieve the result
        for (Future future : list) {
            try {
                sum += Integer.parseInt(future.get().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println(sum);
        executor.shutdown();
    }
}