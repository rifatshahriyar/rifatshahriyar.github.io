pointer1.c - declaring a simple pointer variable to int and read/write values using the pointer 
pointer2.c - not to do operations for pointer (be careful) 
pointer3.c - demonstrating pointer increment
pointer4.c - demonstrating valid pointer operations
pointer5.c - swap two int variables using pointers (call by reference)
pointer6.c - demonstrating pointer with one dimensional array