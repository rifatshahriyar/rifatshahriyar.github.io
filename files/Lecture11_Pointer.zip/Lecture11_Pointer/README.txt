pointer12.c - implementing own malloc and realloc library functions
pointer13.c - dynamic memory allocation (malloc, realloc, free) with integer pointer 
pointer14.c - demonstrating different ways of allocating a two dimensional array dynamically
pointer15.c - demonstrating function returning pointers
