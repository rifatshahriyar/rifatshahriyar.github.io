#include<stdio.h>

int main() {
    int N = 5, i;
    // two dimensional array of charaters with 10 rows and 80 columns
    // table that can contain 10 strings of maximum length 80
    char text[N][80]; 
    
    for ( i = 0; i < N; i++) {
        printf("String %d: ", i + 1);
        gets(text[i]);
    }
    
    for ( i = 0; i < N; i++) {
        printf("String %d = %s\n", i + 1, text[i]);
    }
    return 0;
}