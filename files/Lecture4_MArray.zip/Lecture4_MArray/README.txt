marray5.c - different ways to initialize a three dimensional array and using a function to print a three dimensional array
marray6.c - matrix addition and subtraction
marray7.c - matrix multiplication
marray8.c - using two dimensional array of characters
marray9.c - using three dimensional array of characters (two dimensional array of string) for a dictionary (v1)
marray10.c - using three dimensional array of characters (two dimensional array of string) for a dictionary (v2)
 