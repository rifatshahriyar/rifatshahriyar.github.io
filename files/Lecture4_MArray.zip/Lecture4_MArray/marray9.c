#include<stdio.h>
#include<string.h>

int main() {
    int N = 11;
    char str[20];
    char words [11][2][10] = {
        "zero", "cero", 
        "one", "uno",
        "two", "dos",
        "three" ,  "tres",
        "four",  "cuatro",
        "five", "cinco",
        "six", "seis",
        "seven",  "siete",
        "eight", "ocho",
        "nine",  "nueve",
        "ten", "diez"
    };
    
    printf("Enter English World: ");
    gets(str);
    
    int i = 0;
    int found = 0;
    for ( i = 0; i < N; i++) {
        if ( !strcmp(str, words[i][0])) {
            printf("Spanish Translation: %s\n", words[i][1]);
            found = 1;
            break;
        }
    }
    if (!found ) {
        printf("Word not found\n");
    }
    return 0;
}