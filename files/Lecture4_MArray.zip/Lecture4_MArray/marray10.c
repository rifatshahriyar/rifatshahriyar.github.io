#include<stdio.h>
#include<string.h>

int main() {
    char str[20];
    char words [][2][10] = {
        "zero", "cero", 
        "one", "uno",
        "two", "dos",
        "three" ,  "tres",
        "four",  "cuatro",
        "five", "cinco",
        "six", "seis",
        "seven",  "siete",
        "eight", "ocho",
        "nine",  "nueve",
        "ten", "diez",
         "$", "$" // end terminator
    };
    
    printf("Enter English World: ");
    gets(str);
    
    int i = 0;
    int found = 0;
    while(strcmp(words[i][0], "$")) {
        if ( !strcmp(str, words[i][0])) {
            printf("Spanish Translation: %s\n", words[i][1]);
            found = 1;
            break;
        }
        i++;
    }
    if (!found ) {
        printf("Word not found\n");
    }
    return 0;
}