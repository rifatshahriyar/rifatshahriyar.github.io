file8.c - read/write one dimensional array to/from a file in binary mode using fwrite and fread
file9.c - read/write two dimensional array to/from a file in binary mode using fwrite and fread
file10.c - using fseek and ftell for random access in a file and to find length of a file
file11.c - a simple contact list with structure and file support
