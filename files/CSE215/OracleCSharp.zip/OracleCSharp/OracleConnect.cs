﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Configuration;
using System.Data;

public class OracleConnect
{
    string connectionString;
    private OracleConnection connection;
    private OracleDataAdapter adapter;
    private OracleCommand command;

    public OracleConnect()
    {
        this.connectionString = ConfigurationManager.ConnectionStrings["oracleConnectionString"].ToString();
        this.connection = new OracleConnection(this.connectionString);
        this.connection.Open();
        this.command = connection.CreateCommand();
        Console.WriteLine("Connected");
    }

    public DataTable searchDB(string query)
    {
        DataTable table = new DataTable();
        this.command.CommandText = query;
        this.adapter = new OracleDataAdapter(command);
        this.adapter.Fill(table);
        return table;
    }


    public DataSet searchDBSet(string query)
    {
        DataSet ds = new DataSet();
        this.command.CommandText = query;
        this.adapter = new OracleDataAdapter(command);
        this.adapter.Fill(ds);
        return ds;
    }

    public int updateDB(string query)
    {
        this.command.CommandText = query;
        return this.command.ExecuteNonQuery();
    }


    public void close()
    {
        connection.Close();
    }

}