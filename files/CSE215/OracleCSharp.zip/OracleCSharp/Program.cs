﻿
using System;
using System.Collections.Generic;
using System.Data;

namespace OracleCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            listProducts();
            while (true)
            {
                Console.WriteLine("Enter Product Information: ");
                Console.Write("Enter Id:");
                int id = Int32.Parse(Console.ReadLine());
                Console.Write("Enter Name:");
                string name = Console.ReadLine();
                Console.Write("Enter Price:");
                double price = Double.Parse(Console.ReadLine());
                Console.Write("Enter Description:");
                string desc = Console.ReadLine();
                addProduct(id, name, price, desc);
                listProducts();
                Console.WriteLine("Do you want to continue (y/n)?");
                string choice = Console.ReadLine();
                if (choice.Equals("n", StringComparison.CurrentCultureIgnoreCase))
                    break;
            }
        }

        public static List<Product> getProducts()
        {
            List<Product> productList = new List<Product>();
            OracleConnect oc = null;
            try
            {
                oc = new OracleConnect();
                String query = "select * from products order by id";
                DataTable datatable = oc.searchDB(query);
                foreach (DataRow dr in datatable.Rows)
                {
                    Product p = new Product();
                    p.Id = Int32.Parse(dr["id"].ToString());
                    p.Name = dr["name"].ToString();
                    p.Price = Double.Parse(dr["price"].ToString());
                    p.Description = dr["description"].ToString();
                    productList.Add(p);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception in listProducts: " + e);
            }
            finally
            {
                try
                {
                    oc.close();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            return productList;
        }

        public static void listProducts()
        {
            List<Product> productList = getProducts();
            foreach (Product p in productList)
            {
                Console.Write(p.Id);
                Console.Write("	");
                Console.Write(p.Name);
                Console.Write("	");
                Console.Write(p.Price);
                Console.Write("	");
                Console.WriteLine(p.Description);
            }

        }

        public static void addProduct(int id, String name, double price, String desc)
        {
            OracleConnect oc = null;
            try
            {
                oc = new OracleConnect();
                String query = string.Format("select * from products where id = {0}", id);
                DataTable datatable = oc.searchDB(query);
                if (datatable.Rows.Count > 0)
                {
                    Console.WriteLine("Product with this Id already exisits");
                }
                else
                {
                    String insertQuery = string.Format(
                            "insert into products(id, name, price, description) values ({0}, '{1}', {2}, '{3}')", id, name,
                            price, desc);
                    oc.updateDB(insertQuery);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception in addProduct: " + e);
            }
            finally
            {
                try
                {
                    oc.close();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }
    }
}
