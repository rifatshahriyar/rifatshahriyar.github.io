import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static List<Product> getProducts() {
        List<Product> productList = new ArrayList<>();
        OracleConnect oc = null;
        try {
            oc = new OracleConnect();
            String query = "select * from products order by id";
            ResultSet rs = oc.searchDB(query);
            while (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setDescription(rs.getString("description"));
                productList.add(p);
            }
        } catch (Exception e) {
            System.out.println("Exception in listProducts: " + e);
        } finally {
            try {
                oc.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return productList;
    }

    public static void listProducts() {
        List<Product> productList = getProducts();
        for (Product p : productList) {
            System.out.print(p.getId());
            System.out.print("	");
            System.out.print(p.getName());
            System.out.print("	");
            System.out.print(p.getPrice());
            System.out.print("	");
            System.out.println(p.getDescription());
        }

    }

    public static void addProduct(int id, String name, double price, String desc) {
        OracleConnect oc = null;
        try {
            oc = new OracleConnect();
            String query = String.format("select * from products where id = %d", id);
            ResultSet rs = oc.searchDB(query);
            if (rs.next()) {
                System.out.println("Product with this Id already exisits");
            } else {
                String insertQuery = String.format(
                        "insert into products(id, name, price, description) values (%d, '%s', %f, '%s')", id, name,
                        price, desc);
                oc.updateDB(insertQuery);
            }
        } catch (Exception e) {
            System.out.println("Exception in addProduct: " + e);
        } finally {
            try {
                oc.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        listProducts();
        while (true) {
            System.out.println("Enter Product Information: ");
            System.out.print("Enter Id:");
            int id = scanner.nextInt();
            System.out.print("Enter Name:");
            String name = scanner.next();
            System.out.print("Enter Price:");
            double price = scanner.nextDouble();
            System.out.print("Enter Description:");
            String desc = scanner.next();
            addProduct(id, name, price, desc);
            listProducts();
            System.out.println("Do you want to continue (y/n)?");
            String choice = scanner.next();
            if (choice.equalsIgnoreCase("n"))
                break;
        }
        scanner.close();
    }
}
