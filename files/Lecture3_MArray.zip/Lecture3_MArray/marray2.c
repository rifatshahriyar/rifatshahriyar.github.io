#include<stdio.h>

int main() {
    // three dimensional array with 3 pages, 3 rows and 3 columns
    int threed[3][3][3]; 
    int i, j, k, c;
    c = 1;
    for ( i = 0; i < 3; i++ ) {  // iterate over pages
        for (  j = 0; j < 3; j++ ) {  // iterate over rows
            for ( k = 0; k < 3; k++ ) {  // iterate over columns
                threed[i][j][k] =c++;
            }  
        }
    }
     for ( i = 0; i < 3; i++ ) {  // iterate over pages  
        for (  j = 0; j < 3; j++ ) {  // iterate over rows
            for ( k = 0; k < 3; k++ ) {  // iterate over columns
                printf("%d ", threed[i][j][k]);
            } 
            printf("  "); 
        }
        printf("\n");
    }
    return 0;
}