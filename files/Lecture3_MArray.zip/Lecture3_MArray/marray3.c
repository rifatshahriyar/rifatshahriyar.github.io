#include<stdio.h>

int main() {
    int i, j, k;
    // one dimensional array to hold temperature of each day of a year
    float tmpday[366] = { };
     // two dimensional array to hold temperature of each day of a year month wise
    float tmpmonth[12][31] = { };
    // three dimensional array to hold temperature of each day of a 10 years
    float tmpyear[10][12][31] = { };
    printf("%d\n", sizeof(tmpday)); 
    printf("%d\n", sizeof(tmpmonth)); 
    printf("%d\n", sizeof(tmpyear)); 
    return 0;
}