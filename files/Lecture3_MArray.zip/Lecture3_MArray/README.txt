marray1.c - declaring a two dimensional array, assign values to the array, and print the array
marray2.c - declaring a three dimensional array, assign values to the array, and print the array
marray3.c - why use multi dimensional array
marray4.c - different ways to initialize a two dimensional array and using a function to print a two dimensional array