import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.wireless.messaging.*;
import javax.microedition.io.*;

public class SendMessage implements CommandListener,Runnable
{
	public Display display;
	public TextBox tf;
	public Command send;
	public Command cancel;
	public TestSMS ts;
	public Alert alert;
	public MessageConnection connection;
	public String data;

	public SendMessage(TestSMS u,String data) 
	{
		this.ts=u;
		this.display=this.ts.display;
		this.data=data;
		send=new Command("Send",Command.OK,0);
		cancel=new Command("Cancel",Command.CANCEL,1);		
		tf=new TextBox("Send To:","",80,TextField.PHONENUMBER);
		tf.addCommand(send);
		tf.addCommand(cancel);
		tf.setCommandListener(this);
		this.display.setCurrent(tf);
		try
		{
			this.connection=(MessageConnection)Connector.open("sms://:6000");		
		}catch(Exception e)
		{
			System.out.println ("Connection creation failed");
		}	
		
	}
	
	public void commandAction(Command c,Displayable d)
	{
		if(c==send)
		{
			if(tf.getString()!=null)
			{
				Thread t=new Thread(this);
				t.start();
			}
		}
		else if(c==cancel)
		{
			try
			{
				this.connection.close();
			}catch(Exception e)
			{
			}	
			this.display.setCurrent(this.ts.f);
		}
		
	}
	
	
	public void run()
	{
		try
    	{
    		String address="sms://"+tf.getString().trim()+":6000";  		
    		TextMessage message=(TextMessage)this.connection.newMessage(MessageConnection.TEXT_MESSAGE);
			message.setAddress(address);
			message.setPayloadText(this.data);
      		this.connection.send(message);
      		alert=new Alert("Message","Message Sent to "+tf.getString(),null,AlertType.CONFIRMATION);
      		alert.setTimeout(3000);
      		this.display.setCurrent(alert);
      		alert.getType().playSound(this.display);      		    		
			this.connection.close();
			this.connection=null;			
      	}
      	catch (Exception e)
    	{
    		try
    		{
    			this.connection.close();
				this.connection=null;	
    		}catch(Exception ex)
    		{
    		}
    		System.out.println("Message Sending Failed");    		
    		alert=new Alert("Message","Message sending failed.",null,AlertType.ERROR);
    		alert.setTimeout(7000);
			this.display.setCurrent(alert);
			alert.getType().playSound(this.display);    		
			
		}
		this.display.setCurrent(this.ts.f);
		
				
	}
}