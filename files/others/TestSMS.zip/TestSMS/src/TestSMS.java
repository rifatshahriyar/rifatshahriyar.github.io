import java.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import javax.wireless.messaging.*;
import javax.microedition.io.*;


public class TestSMS extends MIDlet implements CommandListener
{
	
  public Display display;
  Form f,recieve;
  TextField tf;
  Thread t;
  Command send,exit;
  
  public MessageConnection connection; 
  public Message message;
  String connectionList[],phoneno,data;
  
  
  public TestSMS()
  {
  	f=new Form("Send SMS : ");  
  	recieve=new Form("Received  SMS : ");  	
  	tf=new TextField("","",100,TextField.ANY);
  	send=new Command("Send",Command.OK,0);
  	exit=new Command("Exit",Command.EXIT,0);  	
    f.append(tf);   
  	f.addCommand(send);
  	f.addCommand(exit);
  	recieve.addCommand(exit);
  	f.setCommandListener(this); 
  	recieve.setCommandListener(this);     
  }
  
  
  public void startApp()
  {
    display = Display.getDisplay(this);
    this.connectionList=PushRegistry.listConnections(true);
	if (connectionList == null || connectionList.length == 0)
	{
		display.setCurrent(f); 			
	}
	else
	{	
		if(t==null)
		{
			t=new Thread(new MessageReceiver(this));
			t.start();
		}
	}
	 	      
  }

  public void pauseApp()
  {
  	  	try
		{
			t=null;
			connection.close();
			connection=null;
		}catch(Exception e)
		{
		}	
    
  }

  public void destroyApp(boolean unconditional)
  {
  	  	this.notifyDestroyed();
		try
		{
			t=null;
           	connection.close();           	
           	connection=null;
        }catch (Exception e)
        {
                           
        }
    
  }


  public void commandAction(Command c, Displayable d)
  {   
    
    if(c==exit)
    {    	
    	this.destroyApp(false);
    }
    
    if(c==send)
    {
    	new Thread(new MessageSender(this)).start();
    	
    }
  }
  
  
}
	

class MessageSender implements Runnable
{
	TestSMS ts;
	
	public MessageSender(TestSMS ts)
	{
		this.ts=ts;
		
	}
	
	public void run()
	{
		new SendMessage(this.ts,this.ts.tf.getString());		
	}
	
}



class MessageReceiver implements Runnable
{
	TestSMS ts;
	String data,phone;
	
	public MessageReceiver(TestSMS ts)
	{
		this.ts=ts;
	}
		
	public void run()
	{
		while(true)
		{
			try
			{
				if(ts.connection==null)
				{
					ts.connection = (MessageConnection)Connector.open("sms://:6000");
				}
				ts.message = ts.connection.receive();			
				if(ts.message!=null)
				{
					if(ts.message instanceof TextMessage)
					{
						this.data=((TextMessage)ts.message).getPayloadText();					
					}
					else if(ts.message instanceof BinaryMessage)
					{
						this.data=new String(((BinaryMessage)ts.message).getPayloadData());
					}
					this.phone=ts.message.getAddress();
					
					System.out.print("Message Received:");
					System.out.print("Phone :" + this.phone);
					System.out.println ("Message :"+this.data);
					
					/*if(this.phone.charAt(0)=='s')
  					{
  						this.phone=this.phone.substring(6,this.phone.length()-5);	  
  					}
  					else 
  					{
  						this.phone=this.phone.substring(0,this.phone.length()-5);	  
  					}*/
					this.ts.phoneno=this.phone;															
					this.ts.data=this.data;
					this.ts.connection.close();
					this.ts.connection=null;
					this.ts.recieve.append(this.ts.phoneno + " : " + this.ts.data);
					this.ts.display.setCurrent(this.ts.recieve);
					
					
				}				
			}
			catch(Exception e)
			{
			}
		}
	}	
}