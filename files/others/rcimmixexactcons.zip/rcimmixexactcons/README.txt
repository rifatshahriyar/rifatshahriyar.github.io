rcimmixexactcons.patch can be applied over the revision 10875 of Jikes RVM 

hg clone -r 10875 http://hg.code.sourceforge.net/p/jikesrvm/code jikesrvm
cd jikesrvm
cat rcimmixexactcons.patch | patch -p1
