string6.c - implementing different string library functions (v1) 
string7.c - implementing different string library functions (v2) 
string8.c - implementing different string library functions (v3) 
string9.c - implementing strncmp function
string10.c - different ways of implementing strfind function to find a string in another string 