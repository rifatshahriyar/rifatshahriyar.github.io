pointer7.c - demonstrating pointer with two dimensional array
pointer8.c - demonstrating pointer with string
pointer9.c - demonstrating various string library functions (strcpy, strlen, strcat, strcmp) with pointer
pointer10.c - demonstrating array of pointers to create non-uniform multidimensional array
pointer11.c - dynamic memory allocation (malloc, realloc, free) with character pointer 