#include <stdio.h>
#include <string.h>

struct test {
    unsigned int value : 3;
};

int main( ) {
   struct test t;
   printf( "Sizeof( t ) : %d\n", sizeof(t) );
   
   t.value = 4;
   printf( "t.value : %d\n", t.value );

   t.value = 7;
   printf( "t.value : %d\n", t.value );

   t.value = 8;
   printf( "t.value : %d\n", t.value );

   return 0;
}
