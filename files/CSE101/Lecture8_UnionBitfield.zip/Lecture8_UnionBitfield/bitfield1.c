#include <stdio.h>
#include <string.h>

// define simple structure
struct s {
    int a;
    int b;
} s1;

// define a structure with bit fields 
struct b {
    int a : 1;
    int b : 1;
} b1;
 
int main( ) {
   printf( "Memory size occupied by s1 : %d\n", sizeof(s1));
   printf( "Memory size occupied by b1 : %d\n", sizeof(b1));
   return 0;
}