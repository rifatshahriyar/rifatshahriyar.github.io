#include <stdio.h>
#include <string.h>

struct test {
    unsigned int value : 3;
    unsigned int value2 : 4; 
};

int main( ) {
   struct test t;
   printf( "Sizeof( t ) : %d\n", sizeof(t) );
   
   t.value = 4;
   t.value2 = 6;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2 );

   t.value = 7;
   t.value2 = 8;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2 );


   t.value = 8;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2);


   return 0;
}
