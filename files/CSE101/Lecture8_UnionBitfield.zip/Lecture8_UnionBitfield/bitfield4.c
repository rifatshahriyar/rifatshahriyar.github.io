#include <stdio.h>
#include <string.h>

union test {
    unsigned int value : 3;
    unsigned int value2 : 4; 
};

int main( ) {
   union test t;
   printf( "Sizeof( t ) : %d\n", sizeof(t) );
   
   t.value2 = 6;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2 );

   t.value2 = 8;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2 );

   t.value2 = 10;
   printf( "t.value : %d, ", t.value );
   printf( "t.value2 : %d\n", t.value2);


   return 0;
}
