union1.c - declaring a simple union 
union2.c - declaring a simple union and assign values to different elements 
union3.c - demonstrating value sharing among different elements of union
union4.c - union initialization restriction 
bitfield1.c - declaring a simple bit field and demonstrating sizeof
bitfield2.c - declaring a simple bit field and assign values to bit field variables
bitfield3.c -  bit field with multiple variables
bitfield4.c - declaring a simple bit field with union
