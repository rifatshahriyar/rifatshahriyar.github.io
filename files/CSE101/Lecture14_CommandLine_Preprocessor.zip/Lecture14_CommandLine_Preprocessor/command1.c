#include<stdio.h>

int main(int argc, char *argv[]) {
    int i;
    printf("Total Arguments: %d\n", argc);
    printf("Default argument: %s\n", argv[0]);
    printf("Other arguments: ");
    for ( i = 1; i < argc; i++ ) {
        printf("%s ", argv[i]);
    }
    printf("\n");
    return 0;
}