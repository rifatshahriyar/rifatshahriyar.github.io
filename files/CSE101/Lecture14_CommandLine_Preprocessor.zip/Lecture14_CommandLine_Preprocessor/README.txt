command1.c - printing default and user provided command line arguments
command2.c - summation of input provided in command line
preprocess1.c - demonstrating #include, #define, #undef, #ifndef preprocessors
preprocess2.c - demonstrating #define and #undef in different functions
preprocess3.c - demonstrating preprocessor functions or macro, and different relevant operators
