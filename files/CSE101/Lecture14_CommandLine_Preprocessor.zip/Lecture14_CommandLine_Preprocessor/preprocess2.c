#include<stdio.h>

#define FILE_SIZE 21

void f1() {
    printf("%d\n", FILE_SIZE);
}

#undef FILE_SIZE // without this there will be warning
#define FILE_SIZE 42

void f2() {
    printf("%d\n", FILE_SIZE);
}

int main() {
    f1();
    f2();
    printf("%d\n", FILE_SIZE);
    return 0;
}
