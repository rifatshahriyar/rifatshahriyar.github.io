#include<stdio.h>
#include<stdlib.h>

// run using command2.exe 1 4 5 6 7 8 10
 
 int main(int argc, char *argv[]) {
    int i;
    int sum = 0;
    if (argc < 2) {
        printf("Not enough arguments\n");
        exit(1);
    }
    for ( i = 1; i < argc; i++ ) {
        sum += atoi(argv[i]);
    }
    
    printf("Sum: %d\n", sum);
    
    return 0;
}