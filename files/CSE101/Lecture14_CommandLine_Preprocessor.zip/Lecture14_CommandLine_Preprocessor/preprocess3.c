#include<stdio.h>

#define max(a,b)  ( a > b ? a : b )

#define max3(a, b, c)   ( a > b ? (a > c ? a : c) : ( b > c ? b : c) ) 

#define max4(a,b,c,d)  ( a > max3(b, c, d) ? a : max3(b, c, d) )

// The Macro Continuation (\) Operator 
#define  min(a, b)  \
                           ( a  < b ? a : b )

// The Stringize (#) Operator
#define  message(a, b)  \
                            printf(#a " says to "  #b " - Hello World\n") 


int main() {
    printf("%d\n", max(10,20));
    printf("%d\n", max4(10,25, 50, 20));
    printf("%d\n", min(10,20));
    message(john, doe); // this will work
    return 0;
}