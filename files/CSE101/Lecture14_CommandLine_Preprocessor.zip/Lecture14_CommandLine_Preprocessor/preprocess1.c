#include<stdio.h>

#include "myheader.h" 

#define MAX_ARRAY_LENGTH 20
#define FILE_SIZE 21
#undef FILE_SIZE
#define FILE_SIZE 42

#ifndef MESSAGE
   /* if you remove #include "myheader.h" then MESSAGE will be set by the following */
   #define MESSAGE "Hello World." 
#endif

int main() {
    printf("%d\n", MAX_ARRAY_LENGTH);
    printf("%d\n", FILE_SIZE);
    printf("%s\n", MESSAGE);
    printf("File: %s\n", __FILE__ );
    printf("Date: %s\n", __DATE__ );
    printf("Time: %s\n", __TIME__ );
    printf("Line: %d\n", __LINE__ );
    printf("ANSI: %d\n", __STDC__ );
    return 0;
}
