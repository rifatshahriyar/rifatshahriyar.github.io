string1.c - different ways to initialize a string and how to print a string 
string2.c - input a string using scanf
string3.c - input a string using gets
string4.c - various library functions of string (strcpy, strcat, strcmp, strlen)
string5.c - a simple calculator using strcmp and atoi