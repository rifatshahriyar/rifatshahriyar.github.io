file1.c - declaring a FILE variable, open a file using the FILE variable, and close a file
file2.c - write characters to a file
file3.c - read characters from a file
file4.c - copy one file to another file character by character
file5.c - write strings to a file
file6.c - read/write simple data types to/from a file using fprintf and fscanf
file7.c -  read/write simple data types to/from a file in binary mode using fwrite and fread