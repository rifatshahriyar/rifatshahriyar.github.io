pointer16.c - using pointer to structure variables and introducing the -> operator
pointer17.c - using pointer to structure to access and allocate array of structure variables 
pointer18.c - a simple linked list with addFirst and addLast functionalities
pointerextra.c - a simple linked list with add and delete functionalities (out of syllabus)