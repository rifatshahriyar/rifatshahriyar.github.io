recursion0.c - a simple infinite recursion
recursion1.c - summation of n numbers using recursion
recursion2.c - factorial using recursion
recursion3.c - fibonacci using recursion
recursion4.c - sum of digits using recursion
recursion5.c - gcd using recursion
recursion6.c - string reverse using recursion
recursion7.c - int reverse using recursion
