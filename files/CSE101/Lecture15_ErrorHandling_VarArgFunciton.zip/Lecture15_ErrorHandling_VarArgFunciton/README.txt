error1.c - using errno variable in C for error detection, and perror and strerror functions
error2.c - using EXIT_FAILURE and EXIT_SUCCESS
vararg1.c - variable argument functions in C
