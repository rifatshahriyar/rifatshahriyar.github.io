#include <stdio.h>
#include <errno.h>
#include<string.h>

int main () {
   FILE * fp;
   //fp = fopen ("notexists.txt", "r");
   //fp = fopen("exists.txt", "r");
	
    printf( "Value of errno: %d\n", errno);
    perror("Error printed by perror");
    printf("Error opening file: %s\n", strerror(errno));

   if (fp == NULL) { // or errno != 0
      // file open error
   }
   else {
      fclose (fp);
   }
   
   return 0;
}