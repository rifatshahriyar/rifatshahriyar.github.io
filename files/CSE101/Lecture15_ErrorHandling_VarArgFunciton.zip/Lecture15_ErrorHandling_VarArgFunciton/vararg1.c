#include <stdio.h>
#include <stdarg.h>

double average(int n, ...) {
   va_list valist;
   double sum = 0.0;
   int i;
   /* initialize valist for num number of arguments */
   va_start(valist, n);
   /* access all the arguments assigned to valist */
   for (i = 0; i < n; i++) {
      sum += va_arg(valist, int);
   }
   /* clean memory reserved for valist */
   va_end(valist);
   return sum/n;
}

int max(int n, ...) {
    va_list valist;
   int max, x;
   int i;
   va_start(valist, n);
   for (i = 0; i < n; i++) {
      x =  va_arg(valist, int);
      if ( i == 0) max = x;
      else if ( x > max ) max = x;
   }
   va_end(valist);
   return max;
}

int main() {
   printf("Average of 2, 3, 4, 5 = %f\n", average(4, 2, 3, 4, 5));
   printf("Average of 5, 10, 15 = %f\n", average(3, 5,10,15));
   printf("Max of -1, 5, -3, -6, 9, 6  = %d\n", max(6, -1, 5, -3, -6, 9, 6));
}
