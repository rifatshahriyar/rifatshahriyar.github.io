function mmLoadMenus() {
  if (window.mm_menu_0526141046_0) return;
  window.mm_menu_0526141046_0 = new Menu("root",135,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
mm_menu_0526141046_0.addMenuItem("Downloads Index","location='/technology/software/index.html'");
  mm_menu_0526141046_0.addMenuItem("Database","location='/technology/software/products/database/index.html'");
  mm_menu_0526141046_0.addMenuItem("Application Server","location='/technology/software/products/ias/index.html'");
  mm_menu_0526141046_0.addMenuItem("Enterprise Manager","location='/technology/software/products/oem/index.html'");
  mm_menu_0526141046_0.addMenuItem("JDeveloper","location='/technology/software/products/jdev/index.html'");
  mm_menu_0526141046_0.addMenuItem("Secure Enterprise Search","location='/technology/software/products/search/index.html'");
  mm_menu_0526141046_0.addMenuItem("More...","location='/technology/software/index.html'");
   mm_menu_0526141046_0.hideOnMouseOut=true;
   mm_menu_0526141046_0.menuBorder=1;
   mm_menu_0526141046_0.menuLiteBgColor='#CCCCCC';
   mm_menu_0526141046_0.menuBorderBgColor='#ffffff';
   mm_menu_0526141046_0.bgColor='#CCCCCC';
  window.mm_menu_0526141428_1 = new Menu("root",115,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
mm_menu_0526141428_1.addMenuItem("Documentation Index","location='/technology/documentation/index.html'");
mm_menu_0526141428_1.addMenuItem("Database","location='/technology/documentation/database.html'");
  mm_menu_0526141428_1.addMenuItem("Application Server","location='/technology/documentation/appserver.html'");
  mm_menu_0526141428_1.addMenuItem("Enterprise Manager","location='/technology/documentation/oem.html'");
  mm_menu_0526141428_1.addMenuItem("Developer Suite","location='/technology/documentation/devsuite.html'");
  mm_menu_0526141428_1.addMenuItem("JDeveloper","location='/technology/documentation/jdev.html'");
  mm_menu_0526141428_1.addMenuItem("Collaboration Suite","location='/technology/documentation/collab.html'");
  mm_menu_0526141428_1.addMenuItem("Applications","location='/technology/documentation/applications.html'");
  mm_menu_0526141428_1.addMenuItem("More...","location='/technology/documentation/index.html'");
   mm_menu_0526141428_1.hideOnMouseOut=true;
   mm_menu_0526141428_1.menuBorder=1;
   mm_menu_0526141428_1.menuLiteBgColor='#CCCCCC';
   mm_menu_0526141428_1.menuBorderBgColor='#ffffff';
   mm_menu_0526141428_1.bgColor='#CCCCCC';
  window.mm_menu_0526142449_2 = new Menu("root",175,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
mm_menu_0526142449_2.addMenuItem("Discussion Forums Index","location='http://forums.oracle.com/forums/categoryHome.jspa?categoryID=84'");
  mm_menu_0526142449_2.addMenuItem("Technology Network Community","location='http://forums.oracle.com/forums/category.jspa?categoryID=48'");
  mm_menu_0526142449_2.addMenuItem("Database","location='http://forums.oracle.com/forums/category.jspa?categoryID=18'");
  mm_menu_0526142449_2.addMenuItem("Fusion Middleware","location='http://forums.oracle.com/forums/category.jspa?categoryID=13'");
mm_menu_0526142449_2.addMenuItem("Developer Tools","location='http://forums.oracle.com/forums/category.jspa?categoryID=19'");
mm_menu_0526142449_2.addMenuItem("Enterprise Manager","location='http://forums.oracle.com/forums/category.jspa?categoryID=70'");
mm_menu_0526142449_2.addMenuItem("EPM/Business Intelligence","location='http://forums.oracle.com/forums/category.jspa?categoryID=16'");
mm_menu_0526142449_2.addMenuItem("Technologies","location='http://forums.oracle.com/forums/category.jspa?categoryID=10'");
mm_menu_0526142449_2.addMenuItem("More...","location='http://forums.oracle.com/forums/categoryHome.jspa?categoryID=84'");
   mm_menu_0526142449_2.hideOnMouseOut=true;
   mm_menu_0526142449_2.menuBorder=1;
   mm_menu_0526142449_2.menuLiteBgColor='#CCCCCC';
   mm_menu_0526142449_2.menuBorderBgColor='#ffffff';
   mm_menu_0526142449_2.bgColor='#CCCCCC';
  window.mm_menu_0526143126_3 = new Menu("root",115,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
  mm_menu_0526143126_3.addMenuItem("Articles Index","location='/technology/pub/articles/index.html'");
  mm_menu_0526143126_3.addMenuItem("For Developers","location='/technology/pub/articles/tech_dev.html'");
  mm_menu_0526143126_3.addMenuItem("For DBAs","location='/technology/pub/articles/tech_dba.html'");
  mm_menu_0526143126_3.addMenuItem("Oracle Mag. Current","location='/technology/oramag/oracle/current.html'");
  mm_menu_0526143126_3.addMenuItem("Oracle Mag. Archives","location='/technology/oramag/oracle/index.html'");
  mm_menu_0526143126_3.addMenuItem("Oracle Publishing","location='/oramag/index.html'");
   mm_menu_0526143126_3.hideOnMouseOut=true;
   mm_menu_0526143126_3.menuBorder=1;
   mm_menu_0526143126_3.menuLiteBgColor='#CCCCCC';
   mm_menu_0526143126_3.menuBorderBgColor='#ffffff';
   mm_menu_0526143126_3.bgColor='#CCCCCC';
  window.mm_menu_0526145024_4 = new Menu("root",115,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,false,false);
  mm_menu_0526145024_4.addMenuItem("Sample Code Index","location='/technology/sample_code/index.html'");
  mm_menu_0526145024_4.addMenuItem("Ajax","location='/technology/tech/java/ajax.html'");
  mm_menu_0526145024_4.addMenuItem("EJB","location='/technology/tech/java/ejb30.html'");
  mm_menu_0526145024_4.addMenuItem("J2EE","location='/technology/sample_code/tech/java/j2ee/index.html'");
  mm_menu_0526145024_4.addMenuItem("JavaServer Faces","location='/technology/tech/java/jsf.html'");
  mm_menu_0526145024_4.addMenuItem("JDBC","location='/technology/sample_code/tech/java/sqlj_jdbc/index.html'");
  mm_menu_0526145024_4.addMenuItem("PL/SQL","location='/technology/sample_code/tech/pl_sql/index.html'");
  mm_menu_0526145024_4.addMenuItem("More...","location='/technology/sample_code/index.html'");
   mm_menu_0526145024_4.hideOnMouseOut=true;
   mm_menu_0526145024_4.menuBorder=1;
   mm_menu_0526145024_4.menuLiteBgColor='#CCCCCC';
   mm_menu_0526145024_4.menuBorderBgColor='#ffffff';
   mm_menu_0526145024_4.bgColor='#CCCCCC';
  window.mm_menu_0526145207_5 = new Menu("root",130,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
mm_menu_0526145207_5.addMenuItem("Getting Started Index","location='/technology/getting-started/index.html'");
    mm_menu_0526145207_5.addMenuItem("New OTN Users","location='/technology/about/index.html'");
  mm_menu_0526145207_5.addMenuItem("Developers","location='/technology/developer/index.html'");
mm_menu_0526145207_5.addMenuItem("DBAs","location='/technology/dba/index.html'");
mm_menu_0526145207_5.addMenuItem("ISVs","location='/technology/isv/index.html'");
mm_menu_0526145207_5.addMenuItem("More...","location='/technology/getting-started/index.html'");
 mm_menu_0526145207_5.hideOnMouseOut=true;
   mm_menu_0526145207_5.menuBorder=1;
   mm_menu_0526145207_5.menuLiteBgColor='#CCCCCC';
   mm_menu_0526145207_5.menuBorderBgColor='#ffffff';
   mm_menu_0526145207_5.bgColor='#CCCCCC';
  window.mm_menu_0526151414_6 = new Menu("root",135,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
  mm_menu_0526151414_6.addMenuItem("Tutorials Index","location='/technology/obe/start/index.html'");
  mm_menu_0526151414_6.addMenuItem("Database","location='/technology/obe/11gr1_db/index.htm'");
  mm_menu_0526151414_6.addMenuItem("Real Application Clusters","location='/technology/obe/admin/db10gr2.html'");
  mm_menu_0526151414_6.addMenuItem("Application Server","location='/technology/obe/obe_as_1012/index.html'");
  mm_menu_0526151414_6.addMenuItem("Enterprise Manager","location='/technology/obe/start/em.html'");
  mm_menu_0526151414_6.addMenuItem("JDeveloper","location='/technology/obe/obe1013jdev/index.htm'");
  mm_menu_0526151414_6.addMenuItem("Business Intelligence","location='/technology/obe/obe_bi/bi.html'");
  mm_menu_0526151414_6.addMenuItem("Collaboration Suite","location='/technology/obe/obeocs_1012/admin/install/index.html'");
  mm_menu_0526151414_6.addMenuItem("More...","location='/technology/obe/start/index.html'");
   mm_menu_0526151414_6.hideOnMouseOut=true;
   mm_menu_0526151414_6.menuBorder=1;
   mm_menu_0526151414_6.menuLiteBgColor='#CCCCCC';
   mm_menu_0526151414_6.menuBorderBgColor='#ffffff';
   mm_menu_0526151414_6.bgColor='#CCCCCC';
   window.mm_menu_0526151414_7 = new Menu("root",142,30,"Arial, Helvetica, sans-serif",11,"#000000","#FF0000","#f6f6f6","#f6f6f6","left","middle",4,0,1000,-5,7,true,true,true,1,true,false);
mm_menu_0526151414_7.addMenuItem("blogs.oracle.com","location='http://blogs.oracle.com'");
  mm_menu_0526151414_7.addMenuItem("Oracle's OTN TechBlog","location='http://blogs.oracle.com/otn/'");
  mm_menu_0526151414_7.addMenuItem("Podcasts","location='/technology/syndication/podcasts/index.html'");
   mm_menu_0526151414_7.hideOnMouseOut=true;
   mm_menu_0526151414_7.menuBorder=1;
   mm_menu_0526151414_7.menuLiteBgColor='#CCCCCC';
   mm_menu_0526151414_7.menuBorderBgColor='#ffffff';
   mm_menu_0526151414_7.bgColor='#CCCCCC';

  mm_menu_0526151414_7.writeMenus();
} // mmLoadMenus()

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}