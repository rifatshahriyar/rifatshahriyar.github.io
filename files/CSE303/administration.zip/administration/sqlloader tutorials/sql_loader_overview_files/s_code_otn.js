/* Setting the s_account */
function s_setAccount(){
var s_account="";

var curUrl = location.href;
	
		if(curUrl.indexOf("-stage") != -1 ) {
				s_account = "oracledevall,oracledevotn1";
		}
		else {
				s_account = "oracleglobal,oracleotnlive";
		}
		
		return s_account;
	}
	
	
function navTrack(sitename,language,pagearea,linklabel)
{
var linkvalue ='';
linkvalue = (typeof(sitename) != 'undefined'  || sitename != '') ? (sitename)  : '';
linkvalue = (typeof(language) != 'undefined' || language != '') ? (linkvalue + ':' + language)  : linkvalue;
linkvalue = (typeof(pagearea) != 'undefined' || pagearea != '') ? (linkvalue + ':' + pagearea)  : linkvalue;
linkvalue = (typeof(linklabel) != 'undefined' || linklabel != '') ? (linkvalue + ':' + linklabel) : linkvalue;

  if (linkvalue != '') {   
  
	var s=s_gi(s_setAccount()); 
	s.prop22 = linkvalue;
	s.linkTrackVars="prop22";
	s.tl(this,'o',linkvalue); 
	// Set after previous image is sent to server.
	s_objectID = linkvalue;

  }
}