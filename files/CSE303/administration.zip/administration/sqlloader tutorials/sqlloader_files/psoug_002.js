// psoug.org

document.write(unescape('%3Cscript type="text/javascript"%3E') + '_qoptions={ qacct:"p-f1jRpKGceiDVc" };' + unescape('%3C/script%3E'));
document.write(unescape('%3Cscript type="text/javascript" src="http://edge.quantserve.com/quant.js"%3E%3C/script%3E'));

document.write(unescape("%3Cscript src='" + (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js' %3E%3C/script%3E"));
document.write(unescape('%3Cscript type="text/javascript" src="http://static.crowdscience.com/start-b0979864e7.js"%3E%3C/script%3E'));
document.write(unescape('%3Cscript type="text/javascript" src="http://api.postrank.com/static/engage.js"%3E%3C/script%3E'));
document.write(unescape('%3Cscript type="text/javascript" src="http://track.netshelter.net/js/incl/psoug.org-include.js"%3E%3C/script%3E'));
