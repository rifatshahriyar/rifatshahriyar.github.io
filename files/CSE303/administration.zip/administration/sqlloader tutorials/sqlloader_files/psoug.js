// includes for psoug.org
document.write(unescape('%3Cscript type="text/javascript"%3E') + 'COMSCORE.beacon({c1:2,c2:6036316,c3:"",c4:"",c5:"",c6:"",c15:""});' + unescape('%3C/script%3E'));

