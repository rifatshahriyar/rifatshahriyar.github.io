/* generated javascript */
var skin = 'orafaq';
var stylepath = '/wiki/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

/* MediaWiki:Orafaq.js */
