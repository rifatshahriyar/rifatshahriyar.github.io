import java.util.concurrent.atomic.*;

public class AtomicCounter {
    AtomicLong counter = new AtomicLong(0);

    public void increment() {
        counter.incrementAndGet();
    }

    public long getCounter() {
        return counter.get();
    }
}

