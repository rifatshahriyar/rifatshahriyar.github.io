public class Workers implements Runnable {
	int workItem = 0;
	
	static final int WORK_ITEMS = 1000;
	static final int THREADS = 4;
	
	private void workHard(int workitems) {
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	synchronized
	private int incWorkItem() {
		return workItem++;
	}
	
	@Override
	public void run() {
		int myTasks = 0;
		int myWorkItem = 0;
		while((myWorkItem = incWorkItem()) < WORK_ITEMS) {
			workHard(workItem);
			myTasks++;
		}
		
		System.out.println(Thread.currentThread().getName() + " did " + myTasks);
	}

	public static void main(String[] args) {
		Workers workers = new Workers();
		Thread[] threads = new Thread[THREADS];
		for (int i = 0; i < THREADS; i++) {
			threads[i] = new Thread(workers, "Worker " + i);
		}
		for (int i = 0; i < THREADS; i++) {
			threads[i].start();
		}
		
		System.out.println(Thread.currentThread().getName()+" is twiddling its thumbs");
		
		try {
			for (int i = 0; i < THREADS; i++)
				threads[i].join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("All done!");
	}

}
