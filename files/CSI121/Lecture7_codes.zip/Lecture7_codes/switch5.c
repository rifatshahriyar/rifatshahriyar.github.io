#include<stdio.h>
 
int main() {
    char ch;
    int s;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    s = (ch >='A' && ch <='Z') || (ch>='a' && ch <='z');
    switch(s) {
        case 1:
            switch(ch) {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                case 'A':
                case 'E':
                case 'I':
                case 'O':
                case 'U':
                    printf("Vowel\n");  
                    break;
                default:
                    printf("Consonant\n");  
                }
                break;
        case 0:
            printf("Not a letter\n");
        }
    return 0;
}