#include<stdio.h>

int main( ){
    int day;
    printf("Enter a day: ");
    scanf("%d", &day);
    // no break in switch, so unexpected output
    switch(day) {
        case 1:
            printf("Sat\n");
         case 2:
            printf("Sun\n");
         case 3:
            printf("Mon\n");
         case 4:
            printf("Tues\n");
         case 5:
            printf("Wed\n");
         case 6:
            printf("Thurs\n");
         case 7:
            printf("Fri\n");
         default:
            printf("Invalid\n");   
    }
    return 0;
}

