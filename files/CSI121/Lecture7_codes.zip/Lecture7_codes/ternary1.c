#include<stdio.h>

int main( ){
    int a, b, c;
    int max2, max3;
    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);
    max2 = a > b ? a : b;
    printf("Max: %d\n", max2);
    printf("Enter three numbers: ");
    scanf("%d%d%d", &a, &b, &c);
    max3 = a > b ? ( a > c ? a : c) : ( b > c ? b : c);
    printf("Max: %d\n", max3);
    return 0;
}

