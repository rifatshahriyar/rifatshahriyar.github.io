#include<stdio.h>

int main() {
    int a, b;
    int result;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    /*if ( a > 21 && b <= 21) {
        result = b;
    } 
    else if ( a <= 21 && b > 21) {
        result = a;
    }
    else if (a > 21 && b > 21) {
        result = 0;
    }
    else {
        result = a > b ? a : b;
    }*/
    if ( a > 21) {
        a = 0;
    }
    if ( b > 21) {
        b = 0;
    }
    result = a > b ? a : b;
    printf("%d\n", result);
    return 0;
}