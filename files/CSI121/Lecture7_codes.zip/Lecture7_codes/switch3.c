#include<stdio.h>

int main( ){
    int a, b;
    int result;
    char option;
    printf("Enter first number and then operation and then second number: ");
    scanf("%d %c %d", &a, &option, &b);
    switch(option) {
        case '+':
            result = a + b;
            break;
        case '-':
            result = a - b;
            break;
        case '*':
            result = a * b;
            break;
        default:
            printf("Invalid operation\n");
    }
    printf("Result: %d\n", result);
    return 0;
}

