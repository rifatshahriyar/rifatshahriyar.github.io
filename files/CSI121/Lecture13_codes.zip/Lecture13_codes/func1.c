#include<stdio.h>

int sum() {
    int a, b, c;
    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);
    c = a + b;
    return c;
}

int main() {
    int x;
    x = sum();
    printf("Sum: %d\n", x);
    return 0;
}
