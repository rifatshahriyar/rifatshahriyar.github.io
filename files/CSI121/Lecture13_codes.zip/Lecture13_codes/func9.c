#include<stdio.h>

int main() {
    int x, y, z;
    int totalS, totalP;
    printf("Enter two numbers: " );
    totalS = scanf("%d%d", &x, &y);
    z = x + y;
    totalP = printf("%d + %d = %d\n", x, y, z);
    printf("TotalS: %d, TotalP: %d\n", totalS, totalP);
    return 0;
}
