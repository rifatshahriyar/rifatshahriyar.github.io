#include<stdio.h>

int sum(int, int); // to let main function know about this function

int main() {        
    int x, y, z;
    printf("Enter two numbers: ");
    scanf("%d%d", &x, &y);
    z = sum(x, y);
    printf("Sum: %d\n", z);
    return 0;
}

int sum(int a, int b) {
    return a + b;
}