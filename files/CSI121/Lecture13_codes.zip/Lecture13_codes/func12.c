#include<stdio.h>

int a, b;

int sum() {
    return a + b; // two global variables
}

int main() {
    int c;
    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b); // two global variables
    c = sum();
    printf("Sum: %d\n", c);
    return 0;
}
