#include<stdio.h>

int sum() {
    int a, b, c;
    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);
    c = a + b;
    return c;
}

int main() {
    int x, y, z;
    x = sum();
    y = sum();
    z = x + y;
    // same as z = sum() + sum();
    printf("Total Sum: %d\n", z);
    return 0;
}
