#include<stdio.h>

void f(int a, int b) {
    //int a, b, c; // error because redefination 
    int c;
    a = 1;
    b = 2;
    c = 3;
    printf("%d %d %d\n", a, b, c);
}

int main() {
    int a, b, c;
    a = 10;
    b = 20;
    c = 30;
    printf("%d %d %d\n", a, b, c);
    f(a, b);
    printf("%d %d %d\n", a, b, c);
    return 0;
}
