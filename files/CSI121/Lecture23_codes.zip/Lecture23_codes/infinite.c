#include<stdio.h>

void recursion() {
    recursion();
}

int main() {
    recursion();
    return 0;
}