#include<stdio.h>

int main() {
    double x, sum, term;
    int i, sign;
    printf("Enter x: ");
    scanf("%lf", &x);
    sum = 1;
    term = 1;
    sign = -1;
    for ( i = 1; i <= 100; i++) {
        term = term * (x/i);
        sum = sum + sign * term;
        sign = sign * -1;
    }
    printf("Result: %lf\n", sum);
    return 0;
}