#include<stdio.h>
#define PI 3.14159265359

int main() {
    double x, sum, term;
    int i, sign;
    printf("Enter x: ");
    scanf("%lf", &x);
    x = (x * PI)/180; // degree to radian
    sum = 1;
    term = 1;
    sign = -1;
    for ( i = 1; i <= 100; i++) {
        term = term *  x * x  / ( (2*i) * (2*i-1));
        sum = sum + sign * term;
        sign = sign * -1;
    }
    printf("Result: %lf\n", sum);
    return 0;
}