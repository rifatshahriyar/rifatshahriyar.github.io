#include<stdio.h>

// 1 + x + x^2 + x^3 + x^4 + ..... + x^n
int main() {
    int i, x, n, sum, term;
    printf("Enter x and n: ");
    scanf("%d%d", &x, &n);
    sum = 1; // initial sum
    term = 1;
    for ( i = 1; i <= n; i++) {
        term = term * x;
        sum = sum + term;
    }
    printf("Result: %d\n", sum);
    return 0;
}