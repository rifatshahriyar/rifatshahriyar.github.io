#include<stdio.h>

int main() {
    int i, N;
    int sum, max, min;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for ( i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    sum = 0;
    max = min = a[0];
    printf("You Entered: ");
    for ( i = 0; i < N; i++) {
        sum = sum + a[i];
        if ( a[i] > max) {
            max = a[i];
        }
        if ( a[i] < min) {
            min = a[i];
        }
    }
    printf("Sum: %d\n", sum);
    printf("Max: %d\n", max);
    printf("Min: %d\n", min);
    return 0;
}