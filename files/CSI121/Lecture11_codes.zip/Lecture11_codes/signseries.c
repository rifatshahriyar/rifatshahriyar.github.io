#include<stdio.h>

int main() {
    int i, x, n, sum, term, sign;
    printf("Enter x and n: ");
    scanf("%d%d", &x, &n);
    sum = 1;
    term = 1;
    sign = -1;
    for ( i = 1; i <= n; i++) {
        term = term * x;
        sum = sum + sign * term;
        sign = sign * -1;
    }
    printf("Result: %d\n", sum);
    return 0;
}