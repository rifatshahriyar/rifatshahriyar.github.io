#include<stdio.h>

int main() {
    int a;
    printf("Enter a number: ");
    scanf("%d", &a);
    if ( a %2 == 0 )  {
        printf("a is even\n");
    }
    else {
        printf("a is odd\n");
    }
    /* // same as above, but different check in if
    if ( a %2 )  {
        printf("a is odd\n");
    }
    else {
        printf("a is even\n");
    } */
    return 0;
}
