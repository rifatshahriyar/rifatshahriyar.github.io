#include<stdio.h>

int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    if ( a > b ) 
        printf("a "); // this is part of the if 
        printf(" is greater"); // this is not part of the if
    printf("\n");
    return 0;
}
