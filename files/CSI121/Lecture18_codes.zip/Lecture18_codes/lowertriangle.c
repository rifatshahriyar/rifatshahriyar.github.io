#include<stdio.h>

int main() {
    int i, j, r;
    int lowerTriangle = 1;
    printf("Enter number of rows and columns: ");
    scanf("%d", &r);
    int a[r][r];
    
    printf("Enter the matrix (separate by space): ");
    for ( i =0 ; i< r; i++ ) {
        for ( j = 0; j < r; j++ ) {
            scanf("%d", &a[i][j]);
        }
    }

    printf("The given matrix: \n");
        for ( i =0 ; i< r; i++ ) {
            for ( j = 0; j < r; j++ ) {
                printf("%d ", a[i][j]);
            }
            printf("\n");
        }
    
    for ( i =0 ; i< r; i++ ) {
        for ( j = 0; j < r; j++ ) {
             if ( j  > i && a[i][j] != 0) {
                 lowerTriangle = 0;
             }
             if ( j <= i && a[i][j] == 0) {
                 lowerTriangle = 0;
             }
        }
    }
    
    if (lowerTriangle == 1) {
       printf("A Lower Triangular Matrix: \n");
    }
    else {
          printf("Not a Lower Triangular Matrix: \n");
    }
    return 0;
}