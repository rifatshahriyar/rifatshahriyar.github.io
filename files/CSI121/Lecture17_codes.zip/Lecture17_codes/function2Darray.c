#include<stdio.h>

void print2DArray(int r, int c, int a[][c]) {
    int i, j;
     for ( i = 0; i < r; i++ ) {  // iterate over rows
        for (  j = 0; j < c; j++ ) {  // iterate over columns
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
}

int main() {
    // two dimensional array initialization
    int a[3][4] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    int b[3][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int c[3][4] = {{1,2}, {3,4}, {5,6}};
    print2DArray(3, 4, b);
    print2DArray(3, 4, c);
    return 0;
}