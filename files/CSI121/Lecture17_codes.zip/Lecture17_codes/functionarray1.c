#include<stdio.h>

void f(int a[], int N) {
    int i;
    for (i = 0; i < N; i++) {
        printf("%d ", a[i]);
    }    
    printf("\n");
}

int main() {
    int i, N;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    f(a, N);
    return 0;
}
