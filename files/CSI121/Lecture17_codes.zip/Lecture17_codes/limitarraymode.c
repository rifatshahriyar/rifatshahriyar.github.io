#include<stdio.h>

int main() {
    int i, N, max, val;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    int c[10]={ }; // array to hold the counts
    printf("Enter the numbers (between 0 - 9): ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < N; i++) {
        c[a[i]]++;
    }
    max = c[0];
    for (i = 0; i < 10; i++) {
        if ( max < c[i]) {
            max = c[i];
            val = i;
        }
    }
    printf("Mode is %d - %d times\n", val, max);
    return 0;
}