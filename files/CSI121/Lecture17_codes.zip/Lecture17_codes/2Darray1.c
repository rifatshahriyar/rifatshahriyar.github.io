#include<stdio.h>

int main() {
    // two dimensional array with 4 rows and 5 columns
    int twod[2][3]; 
    int i, j;
    for ( i = 0; i < 2; i++ ) {   // iterate over rows
        for (  j = 0; j < 3; j++ ) {   // iterate over columns
            twod[i][j] = i + j;
        }
    }
    for ( i = 0; i < 2; i++ ) {  // iterate over rows
        for (  j = 0; j < 3; j++ ) {  // iterate over columns
            printf("%d ", twod[i][j]);
        }
        printf("\n");
    }
    return 0;
}