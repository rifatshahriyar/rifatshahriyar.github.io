#include<stdio.h>

int main( ) 
{
    printf("Welcome to C!");
    return 0;
}