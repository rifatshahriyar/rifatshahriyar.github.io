#include<stdio.h>

int main() {
    int num;
    char grade;
    printf("Enter your number: ");
    scanf("%d", &num);
    if ( num >= 0 && num < 60) {
        grade = 'F';
    }
    if ( num >= 60 && num < 70) {
        grade = 'D';
    }
     if ( num >= 70 && num < 80) {
        grade = 'C';
    }
     if ( num >= 80 && num < 90) {
        grade = 'B';
    }
     if ( num >= 90 && num <= 100) {
        grade = 'A';
    }
    printf("Your grade: %c\n", grade);
    return 0;
}