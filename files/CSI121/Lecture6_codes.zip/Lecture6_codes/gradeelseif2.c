#include<stdio.h>

int main() {
    int num;
    char grade;
    printf("Enter your number: ");
    scanf("%d", &num);
    
    if (num < 60 ) {
        grade = 'F';
    }
    else if ( num < 70) {
        grade = 'D';
    }
    else if (num < 80) {
        grade = 'C';
    }
    else if (num < 90) {
        grade = 'B';
    }
    else {
        grade = 'A';   
    }
    printf("Your grade: %c\n", grade);
    return 0;
}