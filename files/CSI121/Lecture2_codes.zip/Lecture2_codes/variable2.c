#include<stdio.h>

int main() {
	char c;
	int i;
	float f;
	double d;
	c = 'a';
	i = 100;
	f = 12.34;
	d = 1234567.89123;
	printf("c = %c, %d\n", c, sizeof(char));
	printf("i = %d, %d\n", i, sizeof(int));
	printf("f = %f, %d\n", f, sizeof(float));
	printf("d = %lf, %d\n", d, sizeof(double));
	return 0;
}