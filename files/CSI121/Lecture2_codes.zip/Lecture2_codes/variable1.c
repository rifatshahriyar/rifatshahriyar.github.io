#include<stdio.h>

int main() {
    int a;
    a = 100;
    // int a = 100;
    printf("%d\n", a);
    return 0;    
}
