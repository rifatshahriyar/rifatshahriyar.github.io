#include<stdio.h>

int main() {
    int a, b, sum;
    char c;
    c = 'y';
    while (c == 'y') {
        printf("Enter a and b: ");
        scanf("%d%d", &a, &b);
        printf("Sum: %d\n", a+b);  
        printf("More? (y/n): ");          
        scanf(" %c", &c);
    }
    return 0;
}