#include<stdio.h>

int main() {
    int n, sum, d;
    sum = 0;
    printf("Enter n: ");
    scanf("%d", &n);
    while (n != 0) {
        d = n % 10;
        sum = sum + d;
        n = n / 10;
    }
    printf("DigitSum: %d\n", sum);
    return 0;
}