#include<stdio.h>

int main() {
    int n, i;
    printf("How many stars: ");
    scanf("%d", &n);
    i = 1; // initialization
    while ( i <= n) { // condition
        printf("*"); // body
        i++; // increment
    }
    printf("\n");
    return 0;
}