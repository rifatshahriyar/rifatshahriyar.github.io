#include<stdio.h>

int main() {
    int n, i, sum;
    sum = 0;
    printf("Enter n: ");
    scanf("%d", &n);
    i = 1;
    while ( i <= n) {
        sum = sum + i;
        i++;
    }
    printf("Sum: %d\n", sum);
    return 0;
}