#include<stdio.h>

int isPrime(int n) {
        int j;
        for ( j = 2; j * j <= n; j++) {
            if ( n % j == 0) {
                return 0; 
            }
        }
        return 1;
}

int isPerfect(int i) {
        int s = 0;
        int j;
        for ( j = 1; j< i; j++) {
            if ( i % j == 0) {
                s = s + j;
            }
        }
        if ( s == i) {
            return 1;
        }
        else return 0;
}

int main() {
    int i, j, n, isPrime;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("List of Prime Numbers: ");
    for ( i = 1; i <=n; i++) {
            isPrime = 1;
            for ( j = 2; j * j <= i; j++) {
                if ( i % j == 0) {
                    isPrime = 0;
                    break;
                }
            }
            if ( isPrime == 1) {
                printf("%d ", i);
            }
    }
    printf("\n");
    return 0;
}