#include<stdio.h>

int isPrime(int n) {
        int j;
        for ( j = 2; j * j <= n; j++) {
            if ( n % j == 0) {
                return 0; 
            }
        }
        return 1;
}

int main() {
    int i, j, n, c;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("List of Prime Numbers: ");
    for ( i = 1; i <=n; i++) {
        c = isPrime(i);
        if (c == 1) printf("%d ", i);
    }
    printf("\n");
    return 0;
}