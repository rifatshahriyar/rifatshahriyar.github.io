#include<stdio.h>
#include<string.h>

// mystrfind(s,t) - find t anywhere in s
int mystrfind(char haystack[], char needle[])
{
	 int i = 0, j = 0, k = 0;
	  while (haystack[i])  {
           j = 0; 
           k = i;
           while (haystack[k] && needle[j] && haystack[k] == needle[j]) {
                    k++;
                    j++;
            }
			if (needle[j] == '\0') {
                return i;
            }	
            i++;
	  }
	  return -1;
}

int main() {
    char s[80], t[80];
    printf("Enter 1st string: ");
    gets(s);
    printf("Enter 2nd string: ");
    gets(t);
    int cmp = mystrfind(s, t); 
    printf("Finding %s in %s : %d\n", t, s, cmp);
    return 0;
}
