#include<stdio.h>

int main() {
    int n, i, mult;
    mult = 1;
    printf("Enter n: ");
    scanf("%d", &n);
    i = 1;
    while ( i <= n) {
        mult = mult * i;
        i++;
    }
    printf("Mult: %d\n", mult);
    return 0;
}