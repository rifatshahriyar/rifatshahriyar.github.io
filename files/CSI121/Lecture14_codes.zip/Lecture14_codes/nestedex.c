#include<stdio.h>

int main() {
    double x, sum, pow, fact;
    int i, j;
    printf("Enter x: ");
    scanf("%lf", &x);
    sum = 1;
    pow = 1;
    fact = 1;
    for ( i = 1; i <= 100; i++) {
        pow = 1;
        fact = 1;
        for ( j = 1; j<= i; j++) {
            pow = pow * x;
        }
        for ( j = 1; j<= i; j++) {
            fact = fact * j;
        }
        sum = sum + pow/fact;
    }
    printf("Result: %lf\n", sum);
    return 0;
}