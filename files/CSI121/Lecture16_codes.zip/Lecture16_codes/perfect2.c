#include<stdio.h>

int isPerfect(int n) {
        int s = 0;
        int j;
        for ( j = 1; j< n; j++) {
            if ( n % j == 0) {
                s = s + j;
            }
        }
        if ( s == n) {
            return 1;
        }
        else return 0;
}

int main() {
    int i, j, n, c;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("List of Perfect Numbers: ");
    for ( i = 1; i <=n; i++) {
        c = isPerfect(i);
        if (c == 1) printf("%d ", i);
    }
    printf("\n");
    return 0;
}