#include<stdio.h>

int main() {
    int i, j, index, N, total, count;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    total = 0;
    count = 0;
    for (i = 0; i < N; i++) {
        count = 1;
        for (j=i+1; j < N; j++) {
            if (a[i] == a[j]) {
                count = 0;
                break;
            }
        }
        if (count == 1) {
            total++;
        }
    }
    printf("Total unique element: %d\n", total);
    return 0;
}