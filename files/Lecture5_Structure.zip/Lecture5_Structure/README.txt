struct1.c - declaring a structure, assign structure elements and print them
struct2.c - input structure elements using scanf and print a structure in a function
struct3.c - declaring nested structure and assign and print structure elements
struct4.c - using structure as a parameter to functions and return structure from functions
struct5.c - using typedef to redefine structure name
struct6.c - using array of structure
struct7.c -  a simple contact list using array of structure